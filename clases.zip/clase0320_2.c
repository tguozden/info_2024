#include<stdio.h>

int main(){
  
  int j;
   
  for (j=0;j<10;j=j+1){
    printf("j = %d\n", j);
  }


  

  return 0;
}
