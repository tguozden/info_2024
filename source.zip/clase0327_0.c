#include<stdio.h>

#define N 10

int main(){
  
  int v[4];
  
  v[0] = 10;
  v[1] = 11;
  v[2] = 12;
  v[3] = 13;
  
  printf("%d %d %d %d\n", v[0], v[1], v[2], v[3]);

  return 0;
}
