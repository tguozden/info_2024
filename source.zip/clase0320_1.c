#include<stdio.h>

int main(){
  
  float a;
  
  a = 1.0/-0.0;
  
  printf("a = %.3f\n", a);
  

  

  return 0;
}
